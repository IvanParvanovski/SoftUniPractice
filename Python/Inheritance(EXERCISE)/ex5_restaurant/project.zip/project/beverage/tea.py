# from ex5_restaurant.project.beverage.hot_beverage import HotBeverage
from project.beverage.hot_beverage import HotBeverage


class Tea(HotBeverage):
    pass



