# from ex4_need_for_speed.project.car import Car
# from ex4_need_for_speed.project.vehicle import Vehicle
from project.car import Car
from project.vehicle import Vehicle


class FamilyCar(Car):
    pass
