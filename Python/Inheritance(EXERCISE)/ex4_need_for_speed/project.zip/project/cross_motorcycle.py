# from ex4_need_for_speed.project.motorcycle import Motorcycle
# from ex4_need_for_speed.project.vehicle import Vehicle
from project.motorcycle import Motorcycle
from project.vehicle import Vehicle


class CrossMotorcycle(Motorcycle):
    pass





