from django.apps import AppConfig


class WatchesConfig(AppConfig):
    name = 'watches'
