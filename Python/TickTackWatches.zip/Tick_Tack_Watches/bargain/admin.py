from django.contrib import admin

from bargain.models import Purchase

admin.site.register(Purchase)
