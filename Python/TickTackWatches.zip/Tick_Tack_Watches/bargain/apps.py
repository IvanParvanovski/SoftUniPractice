from django.apps import AppConfig


class BargainConfig(AppConfig):
    name = 'bargain'
