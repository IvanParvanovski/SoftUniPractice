function numLayers(foldTimes) {
    console.log(0.0005 * Math.pow(2, foldTimes) + 'm');
}

numLayers(1);
numLayers(2);
numLayers(4);
numLayers(21);
