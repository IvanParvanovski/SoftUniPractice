namespace Ex1
{
    public interface IPerson
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}