﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SocialSystem.Data.Migrations
{
    public partial class migration_002 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
