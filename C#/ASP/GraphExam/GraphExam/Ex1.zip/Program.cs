// See https://aka.ms/new-console-template for more information

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace GraphSkeleton
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int companiesCount = int.Parse(Console.ReadLine());
            OrderedDictionary companies = new OrderedDictionary();
            
            for (int i = 0; i < companiesCount; i++)
            {
                string[] companyData = Console.ReadLine().Split(" | ");
                string name = companyData[0];
                string owner = companyData[1];
                
                companies[owner] = name;
            }

            string[] range = Console.ReadLine().Split(" - ");
            
            char startChr = range[0].ToLower().ToCharArray()[0];
            char endChr = range[1].ToLower().ToCharArray()[0];
            
            List<string> keysReversed = new List<string>();

            foreach (string company in companies.Keys)
            {
                keysReversed.Add(company);
            }

            keysReversed.Reverse();
            
            foreach (string key in keysReversed)
            {
                char wordChar = key.ToLower()[0];

                if (wordChar >= startChr && wordChar < endChr)
                {
                    Console.WriteLine($"{key} - {companies[key]}");
                }
            }
        }
    }
}