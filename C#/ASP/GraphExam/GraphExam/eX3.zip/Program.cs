// See https://aka.ms/new-console-template for more information

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace GraphSkeleton
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Graph<int> graph = new Graph<int>(new DFSBehaviour<int>());

            int nodesCount = int.Parse(Console.ReadLine());
            int edgesCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < nodesCount; i++)
            {
                graph.AddNode(i);
            }

            for (int i = 0; i < edgesCount; i++)
            {
                int[] edgeInfo = Console.ReadLine().Split().Select(int.Parse).ToArray();
                int start = edgeInfo[0];
                int end = edgeInfo[1];
                
                graph.AddEdge(start, end);
            }

            int startNode = int.Parse(Console.ReadLine());
            int endNode = int.Parse(Console.ReadLine());
            
            graph.PerformComputation(startNode, endNode);
        }
    }
}