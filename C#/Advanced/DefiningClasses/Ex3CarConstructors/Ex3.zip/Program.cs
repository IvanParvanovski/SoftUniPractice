﻿using System;

namespace Ex3CarConstructors
{
    class Program
    {
        
    }
}