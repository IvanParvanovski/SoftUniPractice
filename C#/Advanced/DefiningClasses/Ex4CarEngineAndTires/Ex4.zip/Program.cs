﻿using System;

namespace Ex4CarEngineAndTires
{
    class Program
    {
       
    }
}