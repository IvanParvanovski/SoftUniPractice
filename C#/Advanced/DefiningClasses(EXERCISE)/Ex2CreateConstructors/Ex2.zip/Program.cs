﻿using System;

namespace Ex2CreateConstructors
{
    class Program
    {
        
    }
}