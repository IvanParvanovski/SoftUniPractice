﻿using System;

namespace Ex1DefineClassPerson
{
    class Program
    {
        
    }
}