﻿using System;

namespace Ex4OpinionPoll
{
    class Program
    {
       
    }
}