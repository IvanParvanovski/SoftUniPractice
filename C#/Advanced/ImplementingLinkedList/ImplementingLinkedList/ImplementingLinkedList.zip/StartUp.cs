﻿using System;
using System.Collections.Generic;

namespace ImplementingLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}