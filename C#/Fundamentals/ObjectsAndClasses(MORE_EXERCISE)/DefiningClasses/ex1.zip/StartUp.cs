﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person p1 = new Person {Name = "Pesho", Age = 20};
            Person p2 = new Person {Name = "Gosho", Age = 18};
            Person p3 = new Person {Name = "Stamat", Age = 43};
        }
    }
}